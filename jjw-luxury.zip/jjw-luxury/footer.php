<?php
/**
 * footer.php — JJ WeddingZ Photography
 * Global footer with dynamic options, sitemap links, and schema.
 *
 * @package JJWeddingZ
 */<?php
$phone_footer  = jjwz_get_option( 'jjw_primary_phone',      '+91 98765 43210' );
$wa_number     = jjwz_get_option( 'jjw_primary_whatsapp',   '919876543210' );
$wa_mode       = jjwz_get_option( 'jjwz_whatsapp_mode',     'simple' );
$wa_link       = ( $wa_mode === 'simple' ) ? 'https://wa.me/' . preg_replace( '/[^0-9]/', '', $wa_number ) : '#';
$copyright_txt = jjwz_get_option( 'jjwz_copyright_text',    '© ' . gmdate('Y') . ' JJ WeddingZ Photography. All Rights Reserved.' );

$socials_raw   = jjwz_get_option( 'jjw_social_media', '[]' );
$socials       = json_decode( $socials_raw, true ) ?: [];
?>

</main><!-- /#jjwz-main-content -->

<!-- ═══════════════════════════════════════════
     PRE-FOOTER CTA BAND
     ═══════════════════════════════════════════ -->
<section class="prefooter-cta" aria-label="Booking call to action">
    <div class="container prefooter-cta__inner">
        <div class="prefooter-cta__text">
            <span class="eyebrow">Begin Your Journey</span>
            <h2 class="prefooter-cta__heading">Every Love Story Deserves<br><em>an Unforgettable Frame.</em></h2>
        </div>
        <div class="prefooter-cta__actions">
            <a href="<?php echo esc_url( $wa_link ); ?>"
               class="btn btn--primary" id="footer-wa-cta" target="_blank" rel="noopener noreferrer">
                Inquire About Your Date
            </a>
            <a href="<?php echo esc_url( home_url( '/portfolio' ) ); ?>"
               class="btn btn--outline-white" id="footer-portfolio-cta">
                View Our Portfolio
            </a>
        </div>
    </div>
</section>

<!-- ═══════════════════════════════════════════
     MAIN FOOTER
     ═══════════════════════════════════════════ -->
<footer class="jjwz-footer" role="contentinfo" aria-label="Site footer">
    <div class="container footer__top">
        <div class="footer__brand">

            <!-- Logo / Name -->
            <?php 
            $logo_url = jjwz_get_option( 'jjw_logo', '' );
            if ( ! empty( $logo_url ) ) : ?>
                <div class="footer__logo">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                        <img src="<?php echo esc_url( $logo_url ); ?>" class="custom-logo" alt="<?php bloginfo( 'name' ); ?>">
                    </a>
                </div>
            <?php elseif ( has_custom_logo() ) : ?>
                <div class="footer__logo"><?php the_custom_logo(); ?></div>
            <?php else : ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer__site-name">
                    <span class="footer__logo-primary">JJ WeddingZ</span>
                    <span class="footer__logo-secondary">Photography</span>
                </a>
            <?php endif; ?>

            <p class="footer__brand-desc">
                Capturing your most profound milestones with international elegance across Delhi NCR and Amritsar. 11+ years of professional excellence.
            </p>

            <!-- Social Icons -->
            <div class="footer__socials" aria-label="Social media links">
                <?php 
                if ( ! empty( $socials ) ) :
                    usort( $socials, function($a, $b) {
                        return (int)($a['sort_order'] ?? 0) <=> (int)($b['sort_order'] ?? 0);
                    });
                    foreach ( $socials as $s ) :
                        if ( empty( $s['enabled'] ) || $s['enabled'] === '0' ) { continue; }
                        $icon = ! empty( $s['icon_url'] ) 
                            ? '<img src="' . esc_url( $s['icon_url'] ) . '" alt="' . esc_attr( $s['name'] ) . '" style="width:20px;height:20px;display:inline-block;vertical-align:middle;">' 
                            : esc_html( $s['name'] );
                        ?>
                        <a href="<?php echo esc_url( $s['url'] ); ?>" class="footer__social-link" target="_blank" rel="noopener" aria-label="<?php echo esc_attr( $s['name'] ); ?>">
                            <?php echo $icon; ?>
                        </a>
                        <?php
                    endforeach;
                endif;
                ?>
            </div>
        </div>59 15.04L2 22l5.115-1.34A9.993 9.993 0 0012.003 22c5.514 0 10-4.486 10-10s-4.486-10-9.997-10zm0 18.212a8.184 8.184 0 01-4.17-1.146l-.3-.178-3.09.81.824-3.01-.195-.31A8.198 8.198 0 013.802 12c0-4.517 3.676-8.195 8.2-8.195 4.517 0 8.196 3.678 8.196 8.195 0 4.52-3.68 8.212-8.196 8.212z"/></svg>
                </a>
            </div>
        </div>

        <!-- Footer Nav Columns -->
        <div class="footer__nav-columns">

            <div class="footer__nav-col">
                <h3 class="footer__nav-heading">Services</h3>
                <ul class="footer__nav-list">
                    <li><a href="<?php echo esc_url( home_url( '/services/wedding-photography' ) ); ?>">Wedding Photography</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/services/pre-wedding' ) ); ?>">Pre-Wedding Shoots</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/services/cinematography' ) ); ?>">Cinematography &amp; Films</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/services/maternity-newborn' ) ); ?>">Maternity &amp; Newborn</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/services/baby-shoot' ) ); ?>">Baby Shoots</a></li>
                </ul>
            </div>

            <div class="footer__nav-col">
                <h3 class="footer__nav-heading">Our Branches</h3>
                <ul class="footer__nav-list">
                    <li><a href="<?php echo esc_url( home_url( '/delhi-ncr' ) ); ?>">Delhi &amp; NCR Branch</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/amritsar' ) ); ?>">Amritsar &amp; Punjab Branch</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About Jaspreet Singh</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/portfolio' ) ); ?>">Portfolio Gallery</a></li>
                </ul>
            </div>

            <div class="footer__nav-col">
                <h3 class="footer__nav-heading">Company</h3>
                <ul class="footer__nav-list">
                    <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About Us</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/blog' ) ); ?>">Wedding Blog</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/client-gallery' ) ); ?>">Client Galleries</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact &amp; Booking</a></li>
                    <li><a href="<?php echo esc_url( home_url( '/privacy-policy' ) ); ?>">Privacy Policy</a></li>
                </ul>
            </div>

            <div class="footer__nav-col">
                <h3 class="footer__nav-heading">Contact</h3>
                <ul class="footer__nav-list footer__contact-list">
                    <li>
                        <a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $phone_footer ) ); ?>" id="footer-phone-link">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.8 19.79 19.79 0 01.1 1.14 2 2 0 012.11 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14.92z"></path></svg>
                            <?php echo esc_html( $phone_footer ); ?>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo esc_url( $wa_link ); ?>" target="_blank" rel="noopener" id="footer-wa-link">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12.003 2a9.987 9.987 0 00-8.59 15.04L2 22l5.115-1.34A9.993 9.993 0 0012.003 22c5.514 0 10-4.486 10-10s-4.486-10-9.997-10zm0 18.212a8.184 8.184 0 01-4.17-1.146l-.3-.178-3.09.81.824-3.01-.195-.31A8.198 8.198 0 013.802 12c0-4.517 3.676-8.195 8.2-8.195 4.517 0 8.196 3.678 8.196 8.195 0 4.52-3.68 8.212-8.196 8.212z"/></svg>
                            WhatsApp Us
                        </a>
                    </li>
                    <li>Delhi NCR &amp; Amritsar, Punjab</li>
                    <li>India &amp; International</li>
                </ul>
            </div>

        </div>
    </div>

    <!-- Footer Bottom Bar -->
    <div class="footer__bottom">
        <div class="container flex-between footer__bottom-inner">
            <p class="footer__copyright"><?php echo wp_kses_post( $copyright_txt ); ?></p>
            <p class="footer__credit">Led by <strong>Jaspreet Singh</strong> — 11 Years of Luxury Photography Excellence</p>
        </div>
    </div>

</footer>

<!-- Floating WhatsApp CTA -->
<a href="<?php echo esc_url( $wa_link ); ?>"
   class="jjwz-wa-float" id="wa-float-btn"
   target="_blank" rel="noopener noreferrer"
   aria-label="Chat on WhatsApp">
    <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12.003 2a9.987 9.987 0 00-8.59 15.04L2 22l5.115-1.34A9.993 9.993 0 0012.003 22c5.514 0 10-4.486 10-10s-4.486-10-9.997-10zm0 18.212a8.184 8.184 0 01-4.17-1.146l-.3-.178-3.09.81.824-3.01-.195-.31A8.198 8.198 0 013.802 12c0-4.517 3.676-8.195 8.2-8.195 4.517 0 8.196 3.678 8.196 8.195 0 4.52-3.68 8.212-8.196 8.212z"/></svg>
    <span class="wa-float__label">Chat Now</span>
</a>

<?php wp_footer(); ?>
</body>
</html>
